/* A polyfill for browsers that don't support ligatures. */
/* The script tag referring to this file must be placed before the ending body tag. */

/* To provide support for elements dynamically added, this script adds
   method 'icomoonLiga' to the window object. You can pass element references to this method.
*/
(function () {
	'use strict';
	function supportsProperty(p) {
		var prefixes = ['Webkit', 'Moz', 'O', 'ms'],
			i,
			div = document.createElement('div'),
			ret = p in div.style;
		if (!ret) {
			p = p.charAt(0).toUpperCase() + p.substr(1);
			for (i = 0; i < prefixes.length; i += 1) {
				ret = prefixes[i] + p in div.style;
				if (ret) {
					break;
				}
			}
		}
		return ret;
	}
	var icons;
	if (!supportsProperty('fontFeatureSettings')) {
		icons = {
			'home': '&#xe602;',
			'house': '&#xe602;',
			'home3': '&#xe60d;',
			'house3': '&#xe60d;',
			'pencil': '&#xe60e;',
			'write': '&#xe60e;',
			'play': '&#xe60f;',
			'video': '&#xe60f;',
			'book': '&#xe610;',
			'read': '&#xe610;',
			'library2': '&#xe603;',
			'bank': '&#xe603;',
			'file-text2': '&#xe611;',
			'file4': '&#xe611;',
			'stack': '&#xe612;',
			'layers': '&#xe612;',
			'folder': '&#xe613;',
			'directory': '&#xe613;',
			'ticket': '&#xe614;',
			'theater': '&#xe614;',
			'cart': '&#xe615;',
			'purchase': '&#xe615;',
			'credit-card': '&#xe616;',
			'money5': '&#xe616;',
			'phone': '&#xe604;',
			'telephone': '&#xe604;',
			'address-book': '&#xe617;',
			'contact': '&#xe617;',
			'envelop': '&#xe618;',
			'mail': '&#xe618;',
			'location2': '&#xe619;',
			'map-marker2': '&#xe619;',
			'calendar': '&#xe605;',
			'date': '&#xe605;',
			'display': '&#xe61a;',
			'screen': '&#xe61a;',
			'laptop': '&#xe61b;',
			'computer': '&#xe61b;',
			'mobile': '&#xe606;',
			'cell-phone': '&#xe606;',
			'tablet': '&#xe61c;',
			'mobile3': '&#xe61c;',
			'drawer': '&#xe61d;',
			'box': '&#xe61d;',
			'drawer2': '&#xe61e;',
			'box2': '&#xe61e;',
			'download': '&#xe61f;',
			'save': '&#xe61f;',
			'upload': '&#xe620;',
			'load': '&#xe620;',
			'database': '&#xe621;',
			'db': '&#xe621;',
			'undo2': '&#xe622;',
			'left': '&#xe622;',
			'redo2': '&#xe623;',
			'right': '&#xe623;',
			'forward': '&#xe624;',
			'right2': '&#xe624;',
			'reply': '&#xe625;',
			'left2': '&#xe625;',
			'bubbles': '&#xe626;',
			'comments': '&#xe626;',
			'user': '&#xe627;',
			'profile2': '&#xe627;',
			'users': '&#xe628;',
			'group': '&#xe628;',
			'user-plus': '&#xe629;',
			'user2': '&#xe629;',
			'user-minus': '&#xe62a;',
			'user3': '&#xe62a;',
			'user-tie': '&#xe607;',
			'user5': '&#xe607;',
			'quotes-left': '&#xe62b;',
			'ldquo': '&#xe62b;',
			'quotes-right': '&#xe62c;',
			'rdquo': '&#xe62c;',
			'spinner6': '&#xe62d;',
			'loading7': '&#xe62d;',
			'search': '&#xe62e;',
			'magnifier': '&#xe62e;',
			'key': '&#xe62f;',
			'password': '&#xe62f;',
			'cog': '&#xe630;',
			'gear': '&#xe630;',
			'stats-dots': '&#xe608;',
			'stats2': '&#xe608;',
			'rocket': '&#xe631;',
			'jet': '&#xe631;',
			'bin': '&#xe632;',
			'trashcan': '&#xe632;',
			'briefcase': '&#xe609;',
			'portfolio': '&#xe609;',
			'power': '&#xe633;',
			'lightning': '&#xe633;',
			'menu': '&#xe634;',
			'list3': '&#xe634;',
			'menu2': '&#xe635;',
			'options2': '&#xe635;',
			'menu3': '&#xe636;',
			'options3': '&#xe636;',
			'menu4': '&#xe637;',
			'options4': '&#xe637;',
			'cloud': '&#xe638;',
			'weather': '&#xe638;',
			'sphere': '&#xe639;',
			'globe': '&#xe639;',
			'eye': '&#xe63a;',
			'views': '&#xe63a;',
			'star-full': '&#xe60a;',
			'rate3': '&#xe60a;',
			'happy': '&#xe63b;',
			'emoticon': '&#xe63b;',
			'angry': '&#xe63c;',
			'emoticon15': '&#xe63c;',
			'plus': '&#xe63d;',
			'add': '&#xe63d;',
			'minus': '&#xe63e;',
			'subtract': '&#xe63e;',
			'cross': '&#xe63f;',
			'cancel': '&#xe63f;',
			'checkmark': '&#xe640;',
			'tick': '&#xe640;',
			'share2': '&#xe641;',
			'social': '&#xe641;',
			'mail4': '&#xe60b;',
			'contact4': '&#xe60b;',
			'facebook': '&#xe642;',
			'brand6': '&#xe642;',
			'facebook2': '&#xe643;',
			'brand7': '&#xe643;',
			'instagram': '&#xe644;',
			'brand10': '&#xe644;',
			'twitter': '&#xe645;',
			'brand11': '&#xe645;',
			'twitter2': '&#xe646;',
			'brand12': '&#xe646;',
			'youtube': '&#xe647;',
			'brand14': '&#xe647;',
			'youtube3': '&#xe648;',
			'brand16': '&#xe648;',
			'youtube4': '&#xe649;',
			'brand17': '&#xe649;',
			'github': '&#xe64a;',
			'brand40': '&#xe64a;',
			'github2': '&#xe64b;',
			'brand41': '&#xe64b;',
			'github4': '&#xe64c;',
			'brand43': '&#xe64c;',
			'wordpress2': '&#xe64d;',
			'brand46': '&#xe64d;',
			'tumblr2': '&#xe64e;',
			'brand51': '&#xe64e;',
			'skype': '&#xe64f;',
			'brand61': '&#xe64f;',
			'linkedin': '&#xe60c;',
			'brand63': '&#xe60c;',
			'linkedin2': '&#xe650;',
			'brand64': '&#xe650;',
			'paypal': '&#xe651;',
			'brand77': '&#xe651;',
			'file-word': '&#xe652;',
			'file12': '&#xe652;',
			'file-excel': '&#xe653;',
			'file13': '&#xe653;',
			'html5': '&#xe654;',
			'w3c': '&#xe654;',
			'html52': '&#xe655;',
			'w3c2': '&#xe655;',
			'git': '&#xe656;',
			'0': 0
		};
		delete icons['0'];
		window.icomoonLiga = function (els) {
			var classes,
				el,
				i,
				innerHTML,
				key;
			els = els || document.getElementsByTagName('*');
			if (!els.length) {
				els = [els];
			}
			for (i = 0; ; i += 1) {
				el = els[i];
				if (!el) {
					break;
				}
				classes = el.className;
				if (/icon-/.test(classes)) {
					innerHTML = el.innerHTML;
					if (innerHTML && innerHTML.length > 1) {
						for (key in icons) {
							if (icons.hasOwnProperty(key)) {
								innerHTML = innerHTML.replace(new RegExp(key, 'g'), icons[key]);
							}
						}
						el.innerHTML = innerHTML;
					}
				}
			}
		};
		window.icomoonLiga();
	}
}());